/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __ARM_KMAP_TYPES_H
#define __ARM_KMAP_TYPES_H


#define KM_TYPE_NR 16

#endif
