/* SPDX-License-Identifier: GPL-2.0 */

#ifndef LINUX_IF_PHONET_H
#define LINUX_IF_PHONET_H

#include <uapi/linux/if_phonet.h>

extern struct header_ops phonet_header_ops;
#endif
