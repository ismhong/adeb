

#ifndef __LINUX_USB_F_ACCESSORY_H
#define __LINUX_USB_F_ACCESSORY_H

#include <uapi/linux/usb/f_accessory.h>

#endif 
