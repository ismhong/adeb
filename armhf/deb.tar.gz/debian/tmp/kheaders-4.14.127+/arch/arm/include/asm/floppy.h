
#ifndef __ASM_ARM_FLOPPY_H
#define __ASM_ARM_FLOPPY_H
#if 0
#include <mach/floppy.h>
#endif

#define fd_outb(val,port)			\
	do {					\
		if ((port) == (u32)FD_DOR)	\
			fd_setdor((val));	\
		else				\
			outb((val),(port));	\
	} while(0)

#define fd_inb(port)		inb((port))
#define fd_request_irq()	request_irq(IRQ_FLOPPYDISK,floppy_interrupt,\
					    0,"floppy",NULL)
#define fd_free_irq()		free_irq(IRQ_FLOPPYDISK,NULL)
#define fd_disable_irq()	disable_irq(IRQ_FLOPPYDISK)
#define fd_enable_irq()		enable_irq(IRQ_FLOPPYDISK)

static inline int fd_dma_setup(void *data, unsigned int length,
			       unsigned int mode, unsigned long addr)
{
	set_dma_mode(DMA_FLOPPY, mode);
	__set_dma_addr(DMA_FLOPPY, data);
	set_dma_count(DMA_FLOPPY, length);
	virtual_dma_port = addr;
	enable_dma(DMA_FLOPPY);
	return 0;
}
#define fd_dma_setup		fd_dma_setup

#define fd_request_dma()	request_dma(DMA_FLOPPY,"floppy")
#define fd_free_dma()		free_dma(DMA_FLOPPY)
#define fd_disable_dma()	disable_dma(DMA_FLOPPY)


#define DMA_FLOPPYDISK		DMA_FLOPPY


static unsigned char floppy_selects[2][4] =
{
	{ 0x10, 0x21, 0x23, 0x33 },
	{ 0x10, 0x21, 0x23, 0x33 }
};

#define fd_setdor(dor)								\
do {										\
	int new_dor = (dor);							\
	if (new_dor & 0xf0)							\
		new_dor = (new_dor & 0x0c) | floppy_selects[fdc][new_dor & 3];	\
	else									\
		new_dor &= 0x0c;						\
	outb(new_dor, FD_DOR);							\
} while (0)


static inline void fd_scandrives (void)
{
#if 0
	int floppy, drive_count;

	fd_disable_irq();
	raw_cmd = &default_raw_cmd;
	raw_cmd->flags = FD_RAW_SPIN | FD_RAW_NEED_SEEK;
	raw_cmd->track = 0;
	raw_cmd->rate = ?;
	drive_count = 0;
	for (floppy = 0; floppy < 4; floppy ++) {
		current_drive = drive_count;
		
		if (start_motor(redo_fd_request))
			continue;
		
		fdc_specify();
		
		output_byte(FD_RECALIBRATE);
		LAST_OUT(UNIT(floppy));
		
		if (!successful) {
			int i;
			for (i = drive_count; i < 3; i--)
				floppy_selects[fdc][i] = floppy_selects[fdc][i + 1];
			floppy_selects[fdc][3] = 0;
			floppy -= 1;
		} else
			drive_count++;
	}
#else
	floppy_selects[0][0] = 0x10;
	floppy_selects[0][1] = 0x21;
	floppy_selects[0][2] = 0x23;
	floppy_selects[0][3] = 0x33;
#endif
}

#define FDC1 (0x3f0)

#define FLOPPY0_TYPE 4
#define FLOPPY1_TYPE 4

#define N_FDC 1
#define N_DRIVE 4

#define CROSS_64KB(a,s) (0)


static void driveswap(int *ints, int dummy, int dummy2)
{
	floppy_selects[0][0] ^= floppy_selects[0][1];
	floppy_selects[0][1] ^= floppy_selects[0][0];
	floppy_selects[0][0] ^= floppy_selects[0][1];
}

#define EXTRA_FLOPPY_PARAMS ,{ "driveswap", &driveswap, NULL, 0, 0 }
	
#endif
