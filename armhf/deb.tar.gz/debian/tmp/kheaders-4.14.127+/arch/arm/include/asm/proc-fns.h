
#ifndef __ASM_PROCFNS_H
#define __ASM_PROCFNS_H

#ifdef __KERNEL__

#include <asm/glue-proc.h>
#include <asm/page.h>

#ifndef __ASSEMBLY__

struct mm_struct;


struct processor {
	
	void (*_data_abort)(unsigned long pc);
	
	unsigned long (*_prefetch_abort)(unsigned long lr);
	
	void (*_proc_init)(void);
	
	void (*check_bugs)(void);
	
	void (*_proc_fin)(void);
	
	void (*reset)(unsigned long addr, bool hvc) __attribute__((noreturn));
	
	int (*_do_idle)(void);
	
	
	void (*dcache_clean_area)(void *addr, int size);

	
	void (*switch_mm)(phys_addr_t pgd_phys, struct mm_struct *mm);
	
#ifdef CONFIG_ARM_LPAE
	void (*set_pte_ext)(pte_t *ptep, pte_t pte);
#else
	void (*set_pte_ext)(pte_t *ptep, pte_t pte, unsigned int ext);
#endif

	
	unsigned int suspend_size;
	void (*do_suspend)(void *);
	void (*do_resume)(void *);
};

#ifndef MULTI_CPU
static inline void init_proc_vtable(const struct processor *p)
{
}

extern void cpu_proc_init(void);
extern void cpu_proc_fin(void);
extern int cpu_do_idle(void);
extern void cpu_dcache_clean_area(void *, int);
extern void cpu_do_switch_mm(phys_addr_t pgd_phys, struct mm_struct *mm);
#ifdef CONFIG_ARM_LPAE
extern void cpu_set_pte_ext(pte_t *ptep, pte_t pte);
#else
extern void cpu_set_pte_ext(pte_t *ptep, pte_t pte, unsigned int ext);
#endif
extern void cpu_reset(unsigned long addr, bool hvc) __attribute__((noreturn));


extern void cpu_do_suspend(void *);
extern void cpu_do_resume(void *);
#else

extern struct processor processor;
#if defined(CONFIG_BIG_LITTLE) && defined(CONFIG_HARDEN_BRANCH_PREDICTOR)
#include <linux/smp.h>

extern struct processor *cpu_vtable[];
#define PROC_VTABLE(f)			cpu_vtable[smp_processor_id()]->f
#define PROC_TABLE(f)			cpu_vtable[0]->f
static inline void init_proc_vtable(const struct processor *p)
{
	unsigned int cpu = smp_processor_id();
	*cpu_vtable[cpu] = *p;
	WARN_ON_ONCE(cpu_vtable[cpu]->dcache_clean_area !=
		     cpu_vtable[0]->dcache_clean_area);
	WARN_ON_ONCE(cpu_vtable[cpu]->set_pte_ext !=
		     cpu_vtable[0]->set_pte_ext);
}
#else
#define PROC_VTABLE(f)			processor.f
#define PROC_TABLE(f)			processor.f
static inline void init_proc_vtable(const struct processor *p)
{
	processor = *p;
}
#endif

#define cpu_proc_init			PROC_VTABLE(_proc_init)
#define cpu_check_bugs			PROC_VTABLE(check_bugs)
#define cpu_proc_fin			PROC_VTABLE(_proc_fin)
#define cpu_reset			PROC_VTABLE(reset)
#define cpu_do_idle			PROC_VTABLE(_do_idle)
#define cpu_dcache_clean_area		PROC_TABLE(dcache_clean_area)
#define cpu_set_pte_ext			PROC_TABLE(set_pte_ext)
#define cpu_do_switch_mm		PROC_VTABLE(switch_mm)


#define cpu_do_suspend			PROC_VTABLE(do_suspend)
#define cpu_do_resume			PROC_VTABLE(do_resume)
#endif

extern void cpu_resume(void);

#include <asm/memory.h>

#ifdef CONFIG_MMU

#define cpu_switch_mm(pgd,mm) cpu_do_switch_mm(virt_to_phys(pgd),mm)

#ifdef CONFIG_ARM_LPAE

#define cpu_get_ttbr(nr)					\
	({							\
		u64 ttbr;					\
		__asm__("mrrc	p15, " #nr ", %Q0, %R0, c2"	\
			: "=r" (ttbr));				\
		ttbr;						\
	})

#define cpu_get_pgd()	\
	({						\
		u64 pg = cpu_get_ttbr(0);		\
		pg &= ~(PTRS_PER_PGD*sizeof(pgd_t)-1);	\
		(pgd_t *)phys_to_virt(pg);		\
	})
#define cpu_set_ttbr0(val)					\
	do {							\
		u64 ttbr = val;					\
		__asm__("mcrr	p15, 0, %0, %1, c2"		\
			: : "r" (ttbr), "r" (ttbr >> 32));	\
	} while (0)

#else
#define cpu_get_ttbr(nr)					\
	({							\
		unsigned long ttbr;				\
		__asm__("mrc	p15, 0, %0, c2, c0, 0"		\
			: "=r" (ttbr));				\
		ttbr;						\
	})

#define cpu_set_ttbr0(val)					\
	do {							\
		u64 ttbr = val;					\
		__asm__("mcr	p15, 0, %0, c2, c0, 0"		\
			: : "r" (ttbr));			\
	} while (0)

#define cpu_get_pgd()	\
	({						\
		unsigned long pg;			\
		__asm__("mrc	p15, 0, %0, c2, c0, 0"	\
			 : "=r" (pg) : : "cc");		\
		pg &= ~0x3fff;				\
		(pgd_t *)phys_to_virt(pg);		\
	})
#endif

#else	

#define cpu_switch_mm(pgd,mm)	{ }

#endif

#endif 
#endif 
#endif 
