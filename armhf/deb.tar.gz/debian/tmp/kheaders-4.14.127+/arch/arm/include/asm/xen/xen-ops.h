#ifndef _ASM_XEN_OPS_H
#define _ASM_XEN_OPS_H

void xen_efi_runtime_setup(void);

#endif 
