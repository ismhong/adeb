

extern void __init feroceon_l2_init(int l2_wt_override);
extern int __init feroceon_of_init(void);

