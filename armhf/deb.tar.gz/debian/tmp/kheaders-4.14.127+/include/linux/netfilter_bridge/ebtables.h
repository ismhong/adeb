/* SPDX-License-Identifier: GPL-2.0 */

#ifndef __LINUX_BRIDGE_EFF_H
#define __LINUX_BRIDGE_EFF_H

#include <linux/if.h>
#include <linux/if_ether.h>
#include <uapi/linux/netfilter_bridge/ebtables.h>


#define EBT_MATCH 0
#define EBT_NOMATCH 1

struct ebt_match {
	struct list_head list;
	const char name[EBT_FUNCTION_MAXNAMELEN];
	bool (*match)(const struct sk_buff *skb, const struct net_device *in,
		const struct net_device *out, const struct xt_match *match,
		const void *matchinfo, int offset, unsigned int protoff,
		bool *hotdrop);
	bool (*checkentry)(const char *table, const void *entry,
		const struct xt_match *match, void *matchinfo,
		unsigned int hook_mask);
	void (*destroy)(const struct xt_match *match, void *matchinfo);
	unsigned int matchsize;
	u_int8_t revision;
	u_int8_t family;
	struct module *me;
};

struct ebt_watcher {
	struct list_head list;
	const char name[EBT_FUNCTION_MAXNAMELEN];
	unsigned int (*target)(struct sk_buff *skb,
		const struct net_device *in, const struct net_device *out,
		unsigned int hook_num, const struct xt_target *target,
		const void *targinfo);
	bool (*checkentry)(const char *table, const void *entry,
		const struct xt_target *target, void *targinfo,
		unsigned int hook_mask);
	void (*destroy)(const struct xt_target *target, void *targinfo);
	unsigned int targetsize;
	u_int8_t revision;
	u_int8_t family;
	struct module *me;
};

struct ebt_target {
	struct list_head list;
	const char name[EBT_FUNCTION_MAXNAMELEN];
	
	unsigned int (*target)(struct sk_buff *skb,
		const struct net_device *in, const struct net_device *out,
		unsigned int hook_num, const struct xt_target *target,
		const void *targinfo);
	bool (*checkentry)(const char *table, const void *entry,
		const struct xt_target *target, void *targinfo,
		unsigned int hook_mask);
	void (*destroy)(const struct xt_target *target, void *targinfo);
	unsigned int targetsize;
	u_int8_t revision;
	u_int8_t family;
	struct module *me;
};


struct ebt_chainstack {
	struct ebt_entries *chaininfo; 
	struct ebt_entry *e; 
	unsigned int n; 
};

struct ebt_table_info {
	
	unsigned int entries_size;
	unsigned int nentries;
	
	struct ebt_entries *hook_entry[NF_BR_NUMHOOKS];
	
	struct ebt_chainstack **chainstack;
	char *entries;
	struct ebt_counter counters[0] ____cacheline_aligned;
};

struct ebt_table {
	struct list_head list;
	char name[EBT_TABLE_MAXNAMELEN];
	struct ebt_replace_kernel *table;
	unsigned int valid_hooks;
	rwlock_t lock;
	
	int (*check)(const struct ebt_table_info *info,
	   unsigned int valid_hooks);
	
	struct ebt_table_info *private;
	struct module *me;
};

#define EBT_ALIGN(s) (((s) + (__alignof__(struct _xt_align)-1)) & \
		     ~(__alignof__(struct _xt_align)-1))
extern int ebt_register_table(struct net *net,
			      const struct ebt_table *table,
			      const struct nf_hook_ops *ops,
			      struct ebt_table **res);
extern void ebt_unregister_table(struct net *net, struct ebt_table *table,
				 const struct nf_hook_ops *);
extern unsigned int ebt_do_table(struct sk_buff *skb,
				 const struct nf_hook_state *state,
				 struct ebt_table *table);


#define BASE_CHAIN (par->hook_mask & (1 << NF_BR_NUMHOOKS))

#define CLEAR_BASE_CHAIN_BIT (par->hook_mask &= ~(1 << NF_BR_NUMHOOKS))

static inline bool ebt_invalid_target(int target)
{
	return (target < -NUM_STANDARD_TARGETS || target >= 0);
}

#endif
