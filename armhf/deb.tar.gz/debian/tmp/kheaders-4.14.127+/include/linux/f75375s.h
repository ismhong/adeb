

#ifndef __LINUX_F75375S_H
#define __LINUX_F75375S_H


struct f75375s_platform_data {
	u8 pwm[2];
	u8 pwm_enable[2];
};

#endif 
