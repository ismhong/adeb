/* SPDX-License-Identifier: GPL-2.0 */


#ifndef	_ROUTER_H
#define	_ROUTER_H

#include <uapi/linux/wanrouter.h>

#endif	
