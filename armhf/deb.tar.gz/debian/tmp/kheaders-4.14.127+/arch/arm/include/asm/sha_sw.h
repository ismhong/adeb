

#ifndef _SHA_SW_H_
#define _SHA_SW_H_

#ifdef __cplusplus
extern "C" {
#endif

#define ATTR_WARN_UNUSED_RESULT __attribute__((warn_unused_result))


#define SHA256_BLOCK_SIZE 64


#define SHA256_DIGEST_SIZE 32


typedef struct {
  uint32_t h[8];
  uint32_t tot_len;
  uint32_t len;
  uint8_t block[2 * SHA256_BLOCK_SIZE];
  uint8_t buf[SHA256_DIGEST_SIZE]; 
} SwSHA256Ctx;



void SWsha256_init(SwSHA256Ctx* ctx);


void SWsha256_update(SwSHA256Ctx* ctx, const uint8_t* data, uint32_t len);


uint8_t* SWsha256_final(SwSHA256Ctx* ctx) ATTR_WARN_UNUSED_RESULT;

#ifdef __cplusplus
}
#endif

#endif 
