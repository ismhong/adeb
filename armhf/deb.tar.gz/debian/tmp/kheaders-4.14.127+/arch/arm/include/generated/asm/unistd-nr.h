#ifndef _ASM_ARM_UNISTD_NR_H
#define _ASM_ARM_UNISTD_NR_H 1




#define __NR_syscalls 400

#endif 
